/*  
  Autor
  Pablo Hermida
  Fecha 01/02/2017
  Descripción: Regionalizar grillas
  Prioridad: normal   
*/

SET SERVEROUT ON SIZE 1000000
SET ECHO OFF
SPOOL .log




@configuracion.sql



SPOOL OFF
exit
 
